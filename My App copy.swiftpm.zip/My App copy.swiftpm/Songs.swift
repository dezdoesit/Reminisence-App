import SwiftUI

struct Songs: View {
    
    let testArray = music
    var body: some View {
        NavigationView{
            List (testArray) { item in
                Group{
                HStack{
                    Image(item.imageName)
                        .resizable()
                        .frame(width: 100, height: 100)
                    VStack(alignment: .leading){
                        Text (item.name)
                        Text (String(format:
                            "Family Name and Relation",item.quantity))
                         .font (.subheadline)
                                .foregroundColor (
                                    .gray)
                            }
                        }
                    }
                }
                .navigationTitle(Text("Songs"))
            }
        }
    }
                            

struct Screen1_Previews: PreviewProvider {
    static var previews: some View {
        Songs()
    }
}

let music: [Musics] = [
    Musics(name: "A lovely Day - Bill Withers", quantity: 1),
    Musics(name: "Happy - Pharrell", quantity: 1),
    Musics(name: "My Funny Valentine - Chet Baker", quantity: 1),
    Musics(name: "Keep on Rollin' - King George ", quantity: 1),
    Musics(name: "Practice What you Preach - Barry White", quantity: 1),
]

struct Musics: Identifiable {
    let id = UUID()
    let name: String
    let quantity: Float
    var imageName: String {return name}
    

}
